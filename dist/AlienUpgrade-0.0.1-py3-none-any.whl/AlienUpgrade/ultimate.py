def recover():
    print("it work")